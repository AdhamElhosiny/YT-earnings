package com.adham.ytearnings.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Blue = Color(0xFF55C8FF)
val Black = Color(0xFF101114)
val CardGray = Color(0xFF202329)
val LightGray = Color(0xFFB4B9C2)

private val Scheme = darkColorScheme(
    primary = Blue, onPrimary = Black,
    background = Black, onBackground = Color.White,
    surface = CardGray, onSurface = Color.White,
    onSurfaceVariant = LightGray, error = Color(0xFFFF6B6B),
)

@Composable
fun YtEarningsTheme(content: @Composable () -> Unit) =
    MaterialTheme(colorScheme = Scheme, content = content)
