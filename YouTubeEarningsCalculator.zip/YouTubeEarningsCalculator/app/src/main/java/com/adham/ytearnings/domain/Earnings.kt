package com.adham.ytearnings.domain

import java.math.BigDecimal
import java.math.RoundingMode
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

enum class Field { LONG_RPM, SHORTS_RPM, RATE, LONG_VIEWS, SHORTS_VIEWS }

data class EarningsInput(
    val longRpm: BigDecimal,
    val shortsRpm: BigDecimal,
    val rate: BigDecimal,
    val longViews: Long,
    val shortsViews: Long,
)

data class EarningsResult(
    val longUsd: BigDecimal,
    val shortsUsd: BigDecimal,
    val totalUsd: BigDecimal,
    val longEgp: BigDecimal,
    val shortsEgp: BigDecimal,
    val totalEgp: BigDecimal,
    val totalViews: Long,
)

object EarningsCalculator {
    /** Full precision (exact BigDecimal math); rounding happens only when formatting. */
    fun calculate(i: EarningsInput): EarningsResult {
        val longUsd = BigDecimal(i.longViews).multiply(i.longRpm).movePointLeft(3)   // views / 1000 * RPM
        val shortsUsd = BigDecimal(i.shortsViews).multiply(i.shortsRpm).movePointLeft(3)
        val totalUsd = longUsd.add(shortsUsd)
        return EarningsResult(
            longUsd = longUsd,
            shortsUsd = shortsUsd,
            totalUsd = totalUsd,
            longEgp = longUsd.multiply(i.rate),
            shortsEgp = shortsUsd.multiply(i.rate),
            totalEgp = totalUsd.multiply(i.rate),
            totalViews = i.longViews + i.shortsViews,
        )
    }
}

sealed interface Validation {
    data class Valid(val input: EarningsInput) : Validation
    data class Invalid(val errors: Map<Field, String>) : Validation
}

object InputValidator {
    private val decimalRegex = Regex("""^(\d+\.?\d*|\.\d+)$""")
    private val wholeRegex = Regex("""^\d+$""")

    fun parseDecimal(raw: String): BigDecimal? {
        val t = raw.trim()
        return if (decimalRegex.matches(t)) t.toBigDecimalOrNull() else null
    }

    fun parseViews(raw: String): Long? {
        val t = raw.trim()
        return if (wholeRegex.matches(t)) t.toLongOrNull() else null
    }

    fun validate(
        longRpm: String, shortsRpm: String, rate: String,
        longViews: String, shortsViews: String,
    ): Validation {
        val errors = linkedMapOf<Field, String>()
        val lr = parseDecimal(longRpm)
        val sr = parseDecimal(shortsRpm)
        val ex = parseDecimal(rate)?.takeIf { it.signum() > 0 }
        val lv = parseViews(longViews)
        val sv = parseViews(shortsViews)

        if (lr == null) errors[Field.LONG_RPM] = "Enter your long videos RPM (0 or more)."
        if (sr == null) errors[Field.SHORTS_RPM] = "Enter your Shorts RPM (0 or more)."
        if (ex == null) errors[Field.RATE] = "Enter an exchange rate greater than 0."
        if (lv == null) errors[Field.LONG_VIEWS] = "Enter whole-number views (0 or more)."
        if (sv == null) errors[Field.SHORTS_VIEWS] = "Enter whole-number views (0 or more)."

        return if (errors.isEmpty()) Validation.Valid(EarningsInput(lr!!, sr!!, ex!!, lv!!, sv!!))
        else Validation.Invalid(errors)
    }
}

object Money {
    private fun fmt(pattern: String) =
        DecimalFormat(pattern, DecimalFormatSymbols(Locale.US)).apply { roundingMode = RoundingMode.HALF_UP }

    fun format(v: BigDecimal): String = fmt("#,##0.00").format(v)
    fun formatWhole(v: Long): String = fmt("#,##0").format(v)
}
