package com.adham.ytearnings.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.adham.ytearnings.domain.EarningsCalculator
import com.adham.ytearnings.domain.EarningsResult
import com.adham.ytearnings.domain.Field
import com.adham.ytearnings.domain.InputValidator
import com.adham.ytearnings.domain.Validation

data class CalculatorUiState(
    val longRpm: String = "",
    val shortsRpm: String = "",
    val rate: String = "",
    val longViews: String = "",
    val shortsViews: String = "",
    val errors: Map<Field, String> = emptyMap(),
    val result: EarningsResult? = null,
)

class CalculatorViewModel : ViewModel() {
    var state by mutableStateOf(CalculatorUiState())
        private set

    /** Converts Arabic-Indic digits/separators to English so numbers stay consistent. */
    private fun normalize(raw: String) = buildString {
        raw.forEach {
            append(
                when (it) {
                    in '\u0660'..'\u0669' -> '0' + (it - '\u0660')
                    in '\u06F0'..'\u06F9' -> '0' + (it - '\u06F0')
                    ',', '\u066B', '\u066C' -> '.'
                    else -> it
                }
            )
        }
    }

    private fun cleanDecimal(raw: String): String {
        var seenDot = false
        return normalize(raw).filter {
            when {
                it in '0'..'9' -> true
                it == '.' && !seenDot -> { seenDot = true; true }
                else -> false
            }
        }.take(12)
    }

    private fun cleanWhole(raw: String) = normalize(raw).filter { it in '0'..'9' }.take(15)

    fun onChange(field: Field, raw: String) {
        val s = state
        val next = when (field) {
            Field.LONG_RPM -> s.copy(longRpm = cleanDecimal(raw))
            Field.SHORTS_RPM -> s.copy(shortsRpm = cleanDecimal(raw))
            Field.RATE -> s.copy(rate = cleanDecimal(raw))
            Field.LONG_VIEWS -> s.copy(longViews = cleanWhole(raw))
            Field.SHORTS_VIEWS -> s.copy(shortsViews = cleanWhole(raw))
        }
        state = next.copy(errors = s.errors - field, result = null)
    }

    fun calculate() {
        val s = state
        state = when (val v = InputValidator.validate(s.longRpm, s.shortsRpm, s.rate, s.longViews, s.shortsViews)) {
            is Validation.Valid -> s.copy(errors = emptyMap(), result = EarningsCalculator.calculate(v.input))
            is Validation.Invalid -> s.copy(errors = v.errors, result = null)
        }
    }

    /** Hides results but keeps every entered value. */
    fun calculateAgain() { state = state.copy(result = null) }

    fun reset() { state = CalculatorUiState() }
}
