package com.adham.ytearnings.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.adham.ytearnings.domain.EarningsResult
import com.adham.ytearnings.domain.Field
import com.adham.ytearnings.domain.Money
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.math.BigDecimal

private data class Spec(val field: Field, val label: String, val hint: String?, val decimal: Boolean)

private val specs = listOf(
    Spec(Field.LONG_RPM, "Long Videos RPM ($)", "Your earnings per 1,000 views on long-form videos, in USD.", true),
    Spec(Field.SHORTS_RPM, "Shorts RPM ($)", "Your earnings per 1,000 Shorts views, in USD.", true),
    Spec(Field.RATE, "USD to EGP Exchange Rate", "How much is 1 US dollar worth in Egyptian Pounds?", true),
    Spec(Field.LONG_VIEWS, "Monthly Long Video Views", null, false),
    Spec(Field.SHORTS_VIEWS, "Monthly Shorts Views", null, false),
)

@Composable
fun CalculatorScreen(vm: CalculatorViewModel = viewModel()) {
    val s = vm.state
    val scroll = rememberScrollState()
    val focus = LocalFocusManager.current
    val scope = rememberCoroutineScope()
    val lastResult = remember { mutableStateOf<EarningsResult?>(null) }
    if (s.result != null) lastResult.value = s.result

    LaunchedEffect(s.result) {
        if (s.result != null) { delay(250); scroll.animateScrollTo(scroll.maxValue) }
    }

    Column(
        Modifier.fillMaxSize().background(Black)
            .statusBarsPadding().navigationBarsPadding().imePadding()
            .verticalScroll(scroll).padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Header()

        specs.forEachIndexed { index, spec ->
            val value = when (spec.field) {
                Field.LONG_RPM -> s.longRpm
                Field.SHORTS_RPM -> s.shortsRpm
                Field.RATE -> s.rate
                Field.LONG_VIEWS -> s.longViews
                Field.SHORTS_VIEWS -> s.shortsViews
            }
            val error = s.errors[spec.field]
            OutlinedTextField(
                value = value,
                onValueChange = { vm.onChange(spec.field, it) },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(spec.label) },
                singleLine = true,
                isError = error != null,
                supportingText = (error ?: spec.hint)?.let { { Text(it) } },
                keyboardOptions = KeyboardOptions(
                    keyboardType = if (spec.decimal) KeyboardType.Decimal else KeyboardType.Number,
                    imeAction = if (index == specs.lastIndex) ImeAction.Done else ImeAction.Next,
                ),
                keyboardActions = KeyboardActions(onDone = { focus.clearFocus() }),
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = CardGray, unfocusedContainerColor = CardGray,
                    errorContainerColor = CardGray,
                    focusedBorderColor = Blue, unfocusedBorderColor = Color.Transparent,
                    focusedLabelColor = Blue, unfocusedLabelColor = LightGray,
                    cursorColor = Blue,
                ),
            )
        }

        Button(
            onClick = { focus.clearFocus(); vm.calculate() },
            modifier = Modifier.fillMaxWidth().height(58.dp),
            shape = RoundedCornerShape(18.dp),
            elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Blue, contentColor = Black),
        ) { Text("Calculate My Earnings", fontSize = 17.sp, fontWeight = FontWeight.Bold) }

        AnimatedVisibility(
            visible = s.result != null,
            enter = fadeIn() + expandVertically() + slideInVertically { it / 4 },
            exit = fadeOut() + shrinkVertically(),
        ) {
            lastResult.value?.let { r ->
                ResultsCard(r) {
                    vm.calculateAgain()
                    scope.launch { scroll.animateScrollTo(0) }
                }
            }
        }

        TextButton(onClick = { focus.clearFocus(); vm.reset() }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
            Text("Reset Calculator", color = LightGray)
        }
    }
}

@Composable
private fun Header() {
    Column(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(Blue),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Filled.PlayArrow, null, tint = Black, modifier = Modifier.size(30.dp)) }
            Text("YouTube Earnings Calculator", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
        Spacer(Modifier.height(8.dp))
        Text("Let's see how much you earned this month!", color = LightGray, fontSize = 15.sp)
    }
}

@Composable
private fun ResultsCard(r: EarningsResult, onAgain: () -> Unit) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = CardGray),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        border = BorderStroke(1.dp, Blue.copy(alpha = 0.35f)),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Your Earnings This Month!", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
            Text("\$${Money.format(r.totalUsd)} USD", fontSize = 36.sp, fontWeight = FontWeight.ExtraBold, color = Blue)
            Text("EGP ${Money.format(r.totalEgp)}", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
            HorizontalDivider(Modifier.padding(vertical = 6.dp), color = Black)
            Breakdown("Long-Form Videos", r.longUsd, r.longEgp)
            Breakdown("YouTube Shorts", r.shortsUsd, r.shortsEgp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Total views", color = LightGray)
                Text(Money.formatWhole(r.totalViews), color = Color.White, fontWeight = FontWeight.SemiBold)
            }
            Text(
                "That's how much your channel earned this month!",
                color = Color.White, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            )
            Text(
                "Estimates based on the numbers you entered.",
                color = LightGray, fontSize = 12.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedButton(
                onClick = onAgain, modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, Blue),
            ) { Text("Calculate Again", color = Blue, fontWeight = FontWeight.SemiBold) }
        }
    }
}

@Composable
private fun Breakdown(title: String, usd: BigDecimal, egp: BigDecimal) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(title, color = LightGray)
        Column(horizontalAlignment = Alignment.End) {
            Text("\$${Money.format(usd)} USD", color = Blue, fontWeight = FontWeight.SemiBold)
            Text("EGP ${Money.format(egp)}", color = Color.White, style = MaterialTheme.typography.bodySmall)
        }
    }
}
