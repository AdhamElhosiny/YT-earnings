package com.adham.ytearnings

import com.adham.ytearnings.domain.*
import java.math.BigDecimal
import org.junit.Assert.*
import org.junit.Test

class EarningsTest {
    private fun input(lr: String, sr: String, rate: String, lv: Long, sv: Long) =
        EarningsInput(BigDecimal(lr), BigDecimal(sr), BigDecimal(rate), lv, sv)

    @Test fun calculatesBothFormats() {
        val r = EarningsCalculator.calculate(input("4.5", "0.05", "50", 100_000, 500_000))
        assertEquals("450.00", Money.format(r.longUsd))
        assertEquals("25.00", Money.format(r.shortsUsd))
        assertEquals("475.00", Money.format(r.totalUsd))
        assertEquals("23,750.00", Money.format(r.totalEgp))
        assertEquals("22,500.00", Money.format(r.longEgp))
        assertEquals("1,250.00", Money.format(r.shortsEgp))
        assertEquals(600_000L, r.totalViews)
    }

    @Test fun zeroesAreAllowed() {
        val r = EarningsCalculator.calculate(input("0", "0", "48.5", 0, 0))
        assertEquals("0.00", Money.format(r.totalUsd))
        assertEquals("0.00", Money.format(r.totalEgp))
    }

    @Test fun roundsOnlyForDisplay() {
        val r = EarningsCalculator.calculate(input("1.234", "0", "1", 1, 0))
        assertEquals(0, BigDecimal("0.001234").compareTo(r.totalUsd))
        assertEquals("0.00", Money.format(r.totalUsd))
    }

    @Test fun validInputsPass() {
        assertTrue(InputValidator.validate("4.5", "0", "50", "1000", "0") is Validation.Valid)
    }

    @Test fun invalidInputsAreRejected() {
        val v = InputValidator.validate("", "-1", "0", "12.5", "abc") as Validation.Invalid
        assertEquals(Field.values().toSet(), v.errors.keys)
    }

    @Test fun parsers() {
        assertNull(InputValidator.parseDecimal("1.2.3"))
        assertNull(InputValidator.parseDecimal("-5"))
        assertNotNull(InputValidator.parseDecimal(".5"))
        assertNull(InputValidator.parseViews("99999999999999999999"))
        assertEquals(1000L, InputValidator.parseViews("1000"))
    }
}
