# YouTube Earnings Calculator (Android)

Kotlin + Jetpack Compose + Material 3. بدون إنترنت، بدون صلاحيات، بدون جمع بيانات.

## بناء الـ APK
1. افتح المجلد في Android Studio (Koala أو أحدث) مع JDK 17 واترك Gradle Sync يكتمل.
2. من الطرفية: `./gradlew assembleRelease` (أو `gradle assembleRelease` لو الـ wrapper غير موجود).
3. الملف الناتج: `app/build/outputs/apk/release/app-release.apk`
   أو من Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s).
4. انقله للموبايل وثبّته (فعّل "التثبيت من مصادر غير معروفة").

الـ release موقّع بمفتاح debug المحلي ليتثبّت مباشرة. للنشر على Google Play أنشئ keystore خاص بك.

## الاختبارات
`./gradlew test`
